# instagram-banner
a powerful tool for banning instagram accounts

REPORT APP V2.0.0

for windows pc and macbook 

developer: https://t.me/profcoders

![3538EC03-31A1-4C43-934D-F2534910A00D_1_105_c](https://github.com/user-attachments/assets/29bf00fb-b4fa-428c-b3b4-74ae598c5947)

# report app supports:

> Telegram

> Instagram 

> TikTok 

> Twitter

> Snapchat

Do not sell this tool!

You’re free to message me for full guide! 

TEAM GROUP 👇
https://t.me/profcoders

# requirements:

⚙️ compatible pc or Mac

⚙️ app sessions 

⚙️ HTTPS proxies

developer: https://t.me/profcoders

software developed with python version 3

# INSTAGRAM REPORT TOOL
Instagram ban tool
INSTAGRAM REPORT TOOL
INSTAGRAM MASS REPORT TOOL
IG REPORT TOOL
INSTAGRAM REPORT BAN
INSTAAGRAM BAN REPORT TOOL
INSTAGRAM REPORTER TOOL
INSTAGRAM MASS REPORT TOOL
INSTAGRAM REPORTING TOOL
INSTAGRAM BAN TOOL
